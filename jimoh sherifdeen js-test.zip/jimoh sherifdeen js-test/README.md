# This is a simple JS Test :slightly_smiling_face:

To complete this test you need to modify the file 'script.js' so that it produces the output as seen in this image -> 
![output screenshot](../main/output.png)


# WHAT TO DO : 
* Order the posts inside the array variable 'posts' (in ascending order)
* After ordering the posts put them inside a the #content div ( in index.html file) (using javascript only)

### Have fun :sunglasses: